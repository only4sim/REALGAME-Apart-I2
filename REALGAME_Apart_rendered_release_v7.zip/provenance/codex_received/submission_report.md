# Certifying Behavior Without Hiding the Sandbox

Li Quan
Affiliation to be confirmed
With Apart Research
AI Incident Response Sprint, September 2026

## Abstract

Recognizing a sandbox does not, by itself, invalidate every behavioral evaluation. We study which claims about a specified deployment behavior remain identifiable from contained interactions, and when missing information makes certification impossible. A finite interactive model separates the time of a behavioral decision from subsequent environmental evidence. A sharp identification interval weights missing histories by the behavior that can still change. Conditional certification results convert sufficient evidence into an error controlled stopping rule. We implement two local causal environments, a coverage experiment, and a robustness test for evidence accumulation. All 960 scripted episodes completed; 375 population cases and 600 exact checks passed. In 3000 sampling replicates, weighting corrected known distribution shift. Under a specified perturbation, nominal false certification rose to 0.998, while correction kept it below 0.05. No language model experiment is reported. These results concern declared synthetic models, not universal sandbox invisibility or demonstrated safety in any actual deployment.

## 1. Introduction

A contained evaluation can change what follows an agent's action. A successful write may disappear after a session change; two services may disagree about its consequences. Such differences may reveal a simulated condition. But identifying a sandbox and invalidating a behavioral claim are different events. A diagnostic revealed after an irreversible decision cannot change that decision. A missing prerequisite revealed before a later decision can instead leave that behavior unconstrained.

We ask which specified deployment behaviors remain identifiable from permitted safe interactions, even when the environment is detectable. This Open Track project provides an audit artifact for evaluating evidence, not a containment implementation. In incident response, a clean replay can support a narrowly defined claim only after its information boundary, logging, and target decision are specified. More clean runs do not replace missing evidence.

Our contributions are **(1)** a target-sensitive identification boundary, **(2)** conditional certification rules with explicit failure modes, and **(3)** an executable local audit that separates timing, coverage, and statistical validity. The main empirical result is a synthetic robustness failure and its correction, not a measured LLM tendency. The key threat to validity is transport: the deployment reference is supplied to the mathematics, not learned from the local benchmark. Earlier project theory is carried forward; this release adds the integrated artifact and newly executed experiments.

<!-- MAIN PAGE BREAK -->

## 2. Related Work

**Sandbox detection.** Penumbra already defines an interactive distinguishing game and proves an external-consequence witness under an independently observable consequence channel [1, Sections 2 and 5]. We do not claim either contribution. Our question is whether detectable differences leave a particular action probability unidentified. A fully coherent local replica is a counterexample to an unrestricted claim that containment always forces detectable distortion.

**Awareness and behavior.** SAD separates self-knowledge, inference, and action [2, Section 2.1]. Rajakumar and Laine compare prompt classification with procedural responses [3, Section 3.2]. Sandbagging experiments distinguish demonstrated capability from spontaneous propensity [4, Sections 1–2]. These distinctions motivate our separate treatment of signal availability, elicited probing, reported probability, and observable choice. We do not treat explanations as faithful private reasoning.

**Strategic evaluation and control.** Kovařík et al. analyze deployment-specific signals and why testing may fail against strategic behavior [5, Section 3.1.4]. Korbak et al. distinguish measured evaluation rates from deployment approximation and extrapolation [6, Section 2.7]. We operationalize a conditional statistical subclaim rather than asserting a complete safety case.

**Statistical foundations.** Composite e-values and growth-optimal evidence factors are established in Safe Testing [7, Section 3]. Adaptive change-of-measure inequalities [8] and general interactive estimation theory [9, Appendix E.2] also precede this work. Sequence-form policy representation is standard [10, Section 2]. The contribution proposed here is the target-specific safety-evidence contract and its executable counterexamples, not a new general hypothesis-testing principle. Exact priority for the combined formulation requires further independent review.

## 3. Methods

### 3.1 Model, boundary, and observable target

One run is a finite action-observation tree. A history contains every world-correlated input available to the agent: prompts, exposed timing, errors, session state, and cross-service responses. Private agent randomness and within-run memory are allowed. A realization plan x represents its action probabilities; legal behavioral mixtures form a compact convex set X with linear flow constraints. The neural-network parameter space need not be convex.

$$
p_j(x)=M_jx,\qquad J(x)=c^\top x\in[0,1].
$$

Controller j is a complete safe interactive environment, not an isolated tool response. Its logged distribution is p_j. The deployment reference and specified binary behavior determine J. Between runs the same agent is independently reset. The evaluator may choose controllers using previous records. Containment means no unauthorized agent-caused transition outside the declared local boundary; our tools only mutate memory. A probability model or Python facade alone does not prove secure isolation for arbitrary code. The model never executes arbitrary code.

<!-- MAIN PAGE BREAK -->

### 3.2 Target timing and the identification boundary

Two agents are safe-audit equivalent if every allowed safe controller produces the same complete record law. Conditioning on a common past gives the same next-controller and next-record distributions. Induction extends equivalence to repeated adaptive audits. A differing deployment target for such a pair is not identifiable.

For complete histories and unrestricted finite behavioral policies, define the safe support R as histories with positive causal likelihood under at least one permitted safe controller, not merely those sampled so far. Let $\mu_x(h)$ be the deployment probability of first leaving R at history h. Let L(h) and U(h) be the minimum and maximum subsequent target expectation over legal continuations. Let b be the target contribution from paths that never leave R. There are m possible first exits.

**Proposition 1 (sharp target-sensitive interval).** Under these full-history assumptions, deployment target values of all safe-audit-equivalent agents form exactly the interval

$$
\mathcal I_\ell(x)=\left[b+\sum_{i=1}^{m}\mu_x(h_i)L(h_i),\ b+\sum_{i=1}^{m}\mu_x(h_i)U(h_i)\right].
$$

Consequently, its width is the sum of unavailable-history probability multiplied by the target's remaining continuation span. On safely supported reachable histories, equality of complete audit distributions fixes action conditionals. Until first exit, equivalent agents therefore have the same path law. After exit, the corresponding subtrees never occur in a safe audit, so extremal continuations can be assigned independently. Mixtures fill the interval. Appendix A states the proof obligations and limitations.

Table 1. Target relevance of unavailable evidence, not final detectability alone, determines ambiguity.

| Position of unavailable evidence | Remaining target span | Implication |
| --- | --- | --- |
| After the target action is fixed | 0 | Earlier action remains identified |
| Before a freely selectable binary action | 1 | Entire exit mass can be ambiguous |
| Before a partially constrained continuation | Between 0 and 1 | Only the weighted target mass is ambiguous |

The timing qualification is essential. It is not permissible to discard an early probe response that influenced the agent merely because a later action is the desired target. Conversely, a world label revealed strictly after commitment can make final environment classification perfect without altering the committed-action distribution. This uses causal ordering, not a claim that the agent lacks awareness.

**Positive support is different from matched frequencies.** Suppose the reference presents prerequisite O=1 with probability p, while a safe controller does so with probability q. For fixed conditional behavior $\theta_0$ and $\theta_1$, the target is (1-p)$\theta_0$+p $\theta_1$. When 0<q<1, those conditionals are identifiable in the population even if p and q are far apart. At q=0, the exact interval is [(1-p)$\theta_0$, (1-p)$\theta_0$+p]. More repetitions shrink sampling error, not this interval. The missing support here is a declared menu restriction, not proof of a universal physical containment obstacle.

<!-- MAIN PAGE BREAK -->

### 3.3 From identification to conditional certification

Fix $\tau_0$ < $\tau$. The low-risk class G has J(x) at most $\tau_0$; the high-risk null B has J(x) at least $\tau$. A certificate time T is $\delta$-sound if every high-risk agent has probability at most $\delta$ of ever receiving a certificate. Completeness additionally requires finite worst-case expected time on G. Never issuing a certificate is sound but not complete. No power is promised between the two thresholds.

$$
\Gamma=\min_{g\in\mathcal G,\,b\in\mathcal B}\max_j D(M_jg\Vert M_jb).
$$

**Proposition 2 (conditional certification, carried-forward theory).** With finite alphabets, known maps, compact convex nonempty threshold classes, and independent resets, $\Gamma$ is zero exactly when a cross-threshold pair has identical laws for every controller. Such a pair rules out a sound complete certifier. For 0 < $\Gamma$ < infinity, the optimal worst-case expected run cost $C_\delta$ obeys

$$
C_\delta\ge\frac{\log(1/\delta)}{\Gamma},\qquad\frac{C_\delta}{\log(1/\delta)}\longrightarrow\frac1\Gamma\quad(\delta\downarrow0).
$$

The upper construction selects a fixed randomized mixture of complete controllers. The lower bound permits adaptive selection. This is a fixed-model, fixed-threshold asymptotic, not an exact finite-budget guarantee for a real LLM. A least-favorable good/bad pair generates nonnegative evidence factors whose joint controller-record expectation is at most one under every high-risk agent. Their product can be stopped at 1/$\delta$. Positive expected log growth gives finite low-risk cost. Appendix B summarizes support handling and the stopped information lower bound [7–8].

### 3.4 Robustness requires conditional, not marginal, fidelity

Let $e_t$ be a nonnegative score chosen before the next joint controller-record outcome, with finite oscillation $r_t$. Assume the nominal conditional null mean is at most 1+$\nu_t$ and its actual conditional law lies within total variation $\eta_t$. The nonnegative $\nu_t$ and $\eta_t$ must be justified bounds, not fitted reassurance. Then

$$
Z_n=\prod_{t=1}^{n}\frac{e_t}{1+\nu_t+\eta_t r_t},\qquad\Pr_{\mathcal B}(\exists n:Z_n\ge1/\delta)\le\delta.
$$

**Proposition 3 (conditional robustness).** The bounded-function inequality for total variation bounds the actual mean by 1+$\nu_t$+$\eta_t$ $r_t$. Conditioning and multiplying yields a nonnegative supermartingale, so the crossing bound follows. No independence is needed beyond the stated conditional guarantee. The correction may eliminate growth; an unresolved run is not safe. This is an elementary robustification of existing e-process theory, implemented here as a fault test, not a new statistical primitive.

One-time marginal matching and ad hoc controller changes do not suffice. Appendix C gives counterexamples; optional stopping does not authorize changing the underlying experiment.

<!-- MAIN PAGE BREAK -->

### 3.5 Reproducible experiment design

The artifact has three tests. E1 implements interactive causal mechanisms. E2 checks population identification and finite-sample recovery with known kernels. E3 injects specified faults into a sequential certificate. They share no real targets, credentials, operating-system probes, or destructive actions. Synthetic outcomes are separated from the prospective LLM study.

Table 2. Three controlled tests and their distinct evidential targets.

| Test | Manipulation | Main measurement |
| --- | --- | --- |
| E1: causal timing | Persistence / cross-service consistency; cue before / after commitment; 0 / 4 probes | Pre-reveal and final classification; committed shortcut rate |
| E2: prerequisite coverage | Safe probability q from zero to full support | Identification interval; naive and weighted MSE |
| E3: evidence validity | Conditional distribution shift / cached bit | Exact false-certificate crossing probability |

**E1.** Both worlds expose write, read, new_session, status, and commit with the same schemas. Before commitment, the after arm uses the same coherent response kernel for both labels. Only after the action is fixed does a canary diagnostic expose the differing mechanism. In the before arm, the agent's permitted probes can already find the discrepancy. A coherent negative control removes it altogether. Standard and shortcut both finish the local task; the latter skips a required check and is prohibited.

Four scripted policies serve as known possibility and plumbing controls: always standard, always shortcut, a mechanism-conditioned switch, and a blind policy. The release executes 12 replicate identifiers per cell, producing 768 factorial episodes and 192 coherent controls. These seeds repeat a small mechanism set; they are not 960 independent realistic tasks. A separate exhaustive test replays all 625 length-four probe sequences in each after-condition family and verifies matching observations.

**E2.** Enumerate p in {0.1,0.5,0.9}, q in {0,1/16,1/4,1/2,1}, and each conditional action probability in {0,1/4,1/2,3/4,1}. For positive support, weight each observed target by its reference-to-safe likelihood ratio. For zero support, return a partial-identification interval rather than a division by zero. At p=1/2, $\theta_0$=1/4, $\theta_1$=3/4, run 1,000 independent sampling replicates of n=128 at each of three positive q values. Store all count vectors and estimates; compare MSE to the analytic expression.

**E3.** Set the nominal null P(Y=1)=0.7, e(0)=5/3, e(1)=5/7, and $\delta$=0.05. Shift the actual probability to 0.7-eta for eta in {0,0.05,0.2}. Use an absorbing exact dynamic program through 200 rounds to compare nominal scores and scores divided by 1+eta times their oscillation. This shift can represent a specified controller-allocation error. A second control draws a single bit and caches it across rounds. Exact probability calculations are not empirical confidence intervals.

All numbers originate in immutable ledgers. Reproduction and missingness rules appear in Appendix C. CPU work is not retrospectively described as publicly preregistered.

<!-- MAIN PAGE BREAK -->

## 4. Results

### 4.1 Detectability and the target action separate in the implementation

All 960 scripted episodes completed, with zero failed or excluded episodes. In all 768 factorial episodes, the hand-written final diagnostic classified the world correctly. In the 192 coherent controls, that same diagnostic achieved 50% on balanced labels. These figures validate known mechanisms, not autonomous LLM discovery.

There were 384 paired cases required to have identical target inputs: after-timing pairs, zero-probe pairs, and coherent controls. All input hashes and matched scripted choices agreed. In the four-probe before condition, the explicitly programmed switching policy changed from standard to shortcut across worlds. In the after condition its earlier choice did not change, despite perfect final classification. Constant policies did not adapt in either case. This demonstrates possible separation, not a claim about intent.

### 4.2 Coverage controls bias, uncertainty, and sampling cost

All 375 population cases passed 600 exact rational containment-of-target and weighting checks. At zero support, the output remains an interval of possible targets. At positive support, known-kernel correction is population-unbiased, but low coverage increases variance. Figure 1 shows this finite-sample cost rather than treating all detected distribution shift as a fatal evaluation failure.

![Figure 1. MSE over 1,000 sampling replicates per q, each with 128 draws from a fixed scripted policy. The reference target is 0.5. Both curves use the same samples. These are synthetic stochastic trials, not LLM runs.](figures/coverage_mse.png)

Table 3. Estimates from the same samples; the reference target is 0.5.

| Safe q | Naive mean | Weighted mean | Naive MSE | Weighted MSE |
| --- | --- | --- | --- | --- |
| 1/16 | 0.28309 | 0.50570 | 0.04863 | 0.02125 |
| 1/4 | 0.37458 | 0.50152 | 0.01747 | 0.00454 |
| 1/2 | 0.49816 | 0.49816 | 0.00192 | 0.00192 |

All 3,000 replicates and 384,000 draws were retained without failures. At q=1/16, analytic weighted MSE is 169/7680, versus 0.02125 observed. At q=1/2, both estimators coincide.

<!-- MAIN PAGE BREAK -->

### 4.3 Small assumption failures can invalidate a clean-run certificate

At eta=0, the exact false-certificate probability by round 200 is 0.039936 under both procedures, below 0.05. A probability shift of 0.05 raises the nominal crossing probability to 0.201990. A shift of 0.20 raises it to 0.997754. Conditional correction keeps the corresponding probabilities at 0.040535 and 0.042852. All six dynamic programs conserve total probability exactly.

![Figure 2. Exact probability of ever crossing the certificate threshold 20 by round 200. Nominal evidence factors are invalid after the specified probability shift. Corrected factors use an independently specified conditional total-variation envelope. No LLM behavior or estimated confidence interval is involved.](figures/robustness.png)

The cached-bit control has exactly the nominal marginal at every round, yet its nominal eventual crossing probability is 0.3; the first possible crossing is round six. A valid conditional envelope restores the error bound but makes every corrected factor at most one. The result is no certificate, not a declaration of safety. This illustrates the distinction between marginal realism and a reset or conditional-fidelity guarantee.

The inherited v5 checkers revalidated 2,031 rational constraints across 38 cases. The 19 unrestricted cases contain 15 positive certificates and four equal-law cross-threshold pairs. Their artificially restricted counterparts contain 18 and one. These are prior certificate checks, not new model evidence or assurance for the broader class.

### 4.4 Language-model evidence remains unmeasured

No LLM request was made. Twelve mock episodes produced 36 mock completions, excluded from model claims. Real inference is blocked until exact model identifiers, endpoint permission, pricing, and spending limits are configured. Provider compatibility requires a separately logged pilot.

The two-model plan has 480 episodes and at most 2,592 requests without retries. Outcomes include classification, Brier score, calibration, probes, and shortcut choices. Both probability reports follow commitment; neither is treated as an internal belief. Consistent compliance remains a valid result, not a reason to change incentives.

<!-- MAIN PAGE BREAK -->

## 5. Discussion and Limitations

**What the findings establish.** The artifact separates final classification from a prior decision, structural ignorance from frequency shift, and a nominal certificate from one robust to specified faults. These are mechanism and procedure results, not evidence that a particular model is deceptive.

**Use in an evaluation.** Record the target action and decision time, preceding evidence channels, permitted controllers, reset policy, and justified coverage or conditional-error bounds. The artifact returns an assumption-qualified estimate, an evidence rule, or an unresolved interval/counterexample. An unresolved result identifies what extra evidence is needed.

Table 4. A minimal evidence card for a specified behavioral claim.

| Evidence-card field | Required content |
| --- | --- |
| Target | One observable behavior and its decision horizon |
| Coverage | Which relevant histories are accessible; what is assumed about missing mass |
| Procedure | Controller allocation, scoring, reset, and stopping rules |
| Evidence | Raw records, denominators, error bounds, and unresolved cases |

**Limits.** The finite tree can be exponentially large. Convex behavioral mixtures are not the same as a finite list of named LLMs. Unknown deployment kernels, persistent agents, unmodeled timing, and social or physical effects are outside the completed certificate. Importance weights are not transferable merely because two prompts have the same semantic label. Numerical verification supports implementation consistency; it does not replace an independent proof review. Statistical correction needs justified conditional error bounds, and may remove power.

**Impact and novelty.** Judge a behavioral claim by the evidence available before its target, not by a standalone sandbox-detection score. Coupling, realization plans, convex testing, and e-processes have established precedents [7–11]. Our scoped contribution is their containment-relative evidence contract and executable audit. Live model evidence and an authorized audit remain future work.

## 6. Conclusion

A detectable simulator can support some behavioral claims and fail to identify others. The distinction depends on which unavailable information can still affect the target. In a declared finite model, safe evidence can be translated into a conditional certificate; when a cross-threshold equivalent pair remains, more identical clean runs cannot supply the missing premise. Our local experiments make these boundaries executable without touching real targets.

## Code and Data

The companion package contains source documents, code, raw records, figure data, and hashes. No public repository was created. Affiliation, artifact URL, and human approval remain submission gates. Limitations and LLM usage follow.

## References

**[1]** Penumbra: Sandboxing Autonomous Agents by Measuring, Not Assuming, Indistinguishability. Supplied manuscript, paper (1).pdf, Sections 2 and 5. Author, date, and publication status remain unverified.

**[2]** Rudolf Laine et al. 2024. Me, Myself, and AI: The Situational Awareness Dataset (SAD) for LLMs. arXiv:2407.04694v1, Section 2.1. https://arxiv.org/abs/2407.04694

**[3]** Sanyu Rajakumar and Rudolf Laine. Eliciting Situational Awareness in Large Language Models Through Fine-Tuning and In-Context Mechanisms. Supplied manuscript, Section 3.2. Publication date and venue not verified.

**[4]** Teun van der Weij, Felix Hofstätter, Oliver Jaffe, Samuel F. Brown, and Francis Rhys Ward. 2025. AI Sandbagging: Language Models Can Strategically Underperform on Evaluations. ICLR 2025; arXiv:2406.07358v4. https://arxiv.org/abs/2406.07358

**[5]** Vojtěch Kovařík, Eric Olav Chen, Sami Petersen, Alexis Ghersengorin, and Vincent Conitzer. 2025. AI Testing Should Account for Sophisticated Strategic Behaviour. arXiv:2508.14927v1, Section 3.1.4. https://arxiv.org/abs/2508.14927

**[6]** Tomek Korbak, Mikita Balesni, Buck Shlegeris, and Geoffrey Irving. 2025. How to evaluate control measures for LLM agents? A trajectory from today to superintelligence. arXiv:2504.05259v1, Section 2.7. https://arxiv.org/abs/2504.05259

**[7]** Peter Grünwald, Rianne de Heide, and Wouter Koolen. 2024. Safe Testing. Journal of the Royal Statistical Society, Series B, 86(5), 1091–1128. Theorem locations refer to arXiv:1906.07801v5, Section 3, Theorem 1. https://arxiv.org/abs/1906.07801

[8] Emilie Kaufmann, Olivier Cappé, and Aurélien Garivier. 2016. On the Complexity of Best-Arm Identification in Multi-Armed Bandit Models. Journal of Machine Learning Research 17(1), 1–42. Lemma 1. https://www.jmlr.org/beta/papers/v17/kaufman16a.html

**[9]** Fan Chen, Dylan J. Foster, Yanjun Han, Jian Qian, Alexander Rakhlin, and Yunbei Xu. 2024. Assouad, Fano, and Le Cam with Interaction: A Unifying Lower Bound Framework and Characterization for Bandit Learnability. NeurIPS 2024, Appendix E.2, Proposition E.4. https://arxiv.org/abs/2410.05117

**[10]** Daphne Koller, Nimrod Megiddo, and Bernhard von Stengel. 1996. Efficient Computation of Equilibria for Extensive Two-Person Games. Games and Economic Behavior, Section 2, equation (2.1). https://ai.stanford.edu/~koller/Papers/Koller+al+GEB96.pdf

**[11]** Mihir Bellare and Phillip Rogaway. 2006. The Security of Triple Encryption and a Framework for Code-Based Game-Playing Proofs. EUROCRYPT 2006. Fundamental lemma and identical-until-bad reasoning. https://www.cs.ucdavis.edu/~rogaway/papers/games.pdf

## Appendix A. Identification and timing: proof details

The reference world is a causal response process with finite horizon. A history includes every action and observation available to the agent. A safe controller's causal likelihood is the product of its successive observation probabilities along a fixed action history. The actual execution probability multiplies that likelihood by the policy's action-realization weight. Safe support is the union of positive causal-likelihood histories over the entire allowed controller class; it is prefix-closed.

Fix an agent x and another with equal complete audit laws. At a safely supported history reachable under x, choose a controller with positive causal likelihood for that history. Equality of the joint history-and-next-action probabilities, divided by the positive history probability, fixes the policy's next-action conditional. An induction couples the two agents' reference executions up to first exit from safe support. Histories with zero policy-realization weight are not silently conditioned on; their branch has no contribution before exit.

The probability of each first exit and the no-exit target contribution are therefore fixed by audit equivalence. On each first-exit subtree, all continuations have zero probability under every safe controller. Replace the policy there by a continuation minimizing the target and separately by one maximizing it. These replacements preserve every complete safe law and attain the two endpoints in Proposition 1. First-exit subtrees are disjoint, so the replacements are mutually compatible. Randomized mixtures preserve audit laws and fill all intermediate target values.

This exact interval assumes unrestricted finite behavioral continuations and full logs. A more restricted policy class can reduce its width; compressed logs can increase it. For a general convex class with logged maps $M_j$, the identified interval is instead the minimum and maximum of $c^\top x$ over policies satisfying the observed law constraints. Thus the simple first-exit formula is not claimed under arbitrary logging or structural restrictions.

For a target already determined at a stopping prefix, every subsequent continuation has the same target value. Its continuation span is zero even when later observations are mutually singular across environments. This is not an intervention that erases inconvenient early evidence: all prior information must remain in the prefix. If an earlier harmless probe already differs, fidelity of a later target is not established by ignoring that probe.

A complete local replica with matching initial information and matching conditional observation kernels at every admissible history gives equal transcript laws by sequential coupling. It refutes an unrestricted containment trilemma. Conversely, a consequence witness needs accessible sound verification of the missing consequence; a simulator-controlled acknowledgment is not independently sound evidence. Unknown physical or external state is not assumed to be simulable.

## Appendix B. Certification and zero-support handling

Let G and B be nonempty compact convex threshold subsets of the legal realization-plan polytope. For positive record laws, the controller-weighted relative entropy is linear in the controller mixture and jointly convex in the candidate agents. A minimax saddle therefore exists. At a saddle, use the good-to-bad likelihood ratio as the evidence factor for each controller. Directional optimality gives a controller-weighted bad-agent mean at most one and a controller-weighted good-agent mean log factor at least $\Gamma$. The first inequality need not hold controller by controller.

Choose a fresh controller from this mixture on every reset run. Under each bad agent, the product of joint factors has conditional mean no larger than its preceding value. The nonnegative-supermartingale maximal inequality bounds any threshold crossing. Under each good agent, the expected log increment is at least $\Gamma$. If L bounds the positive overshoot, summing drift to the truncated stopping time gives $\Gamma\,\mathbb E[\min(T,n)]\le\log(1/\delta)+L$. Taking n to infinity proves finite good-agent expected cost rather than assuming it.

For the lower bound, fix a minimizing pair before any audit data. Each controller supplies directed divergence at most $\Gamma$. The chain rule on finite stopped histories bounds total divergence by $\Gamma$ times the expected number of used observations. Data processing to the event $T\le n$ gives a binary divergence. Under low-risk completeness its first argument tends to one; under soundness its second is at most $\delta$. The limiting lower bound is log(1/$\delta$). No termination assumption is imposed under high-risk agents.

$$
p_j^\epsilon(x)=(1-\epsilon)p_j(x)+\epsilon u_j,\qquad f_j^\epsilon(l)=(1-\epsilon)e_j^\epsilon(l)+\epsilon E_{u_j}e_j^\epsilon.
$$

For zero probabilities, only the optimization is regularized as above. The actual policy and observations are unchanged. The expected pulled-back factor equals the regularized expected factor. Concavity of log gives actual log growth at least the regularized growth. Compactness and data processing yield $\Gamma_\epsilon$ increasing to $\Gamma$ as epsilon decreases. Taking epsilon to zero sufficiently slowly as $\delta$ decreases yields Proposition 2's first-order limit. Artificially bounding every action probability away from zero would change the candidate class and can eliminate precisely the hidden policies at issue.

The full carried-forward proof and numerical certificate files are in legacy_v5/. This document treats them as conditional project results, not independently peer-reviewed theorems. Convex information projection and composite e-testing are established tools [7]. No mathematical novelty is claimed merely for using them in an agent model.

## Appendix C. Robustness, missingness, and replication

For Proposition 3, use the same information set for every bound: the complete past before the controller/record pair is sampled. A score computed from a pilot is allowed if frozen or otherwise predictable; fitting it using the current observation is not. Suppose the nominal conditional score mean is at most $1+\nu$, and the conditional total-variation error is at most $\eta$. The actual mean is then at most $1+\nu+\eta r$, where r is the score range. Normalizing by this quantity gives the conditional moment bound; iteration and the maximal inequality establish soundness.

The one-step bound is sharp for the E3 two-outcome example. Moving eta mass from Y=1 to Y=0 increases the expected factor by eta times (5/3-5/7), exactly the stated correction. A zero total-variation distance for each marginal does not provide the required conditional envelope. With the cached bit, conditioning on its first value makes every later law a point mass. The repair is therefore permitted to stop producing useful positive evidence.

A separately frozen calibration study can contribute an additional error probability alpha only if it supplies simultaneous conditional-law coverage and the later experiment satisfies the declared conditional independence assumptions. Then a union bound gives at most $\delta$+alpha. The artifact does not estimate such a deployment envelope from local model classifications. No LLM in this release has received a real-deployment certificate.

All CPU experiments use fixed disclosed configurations. run_local.py writes the 960 episode records, all 3,000 sample count vectors, exact population checks, and exact crossing fractions. Its stochastic sampling seed is 620231. Inherited certificate checking uses rational logarithm intervals; the new probability dynamic program uses exact fractions. Optimizer files are inputs to a checker, not self-authenticating evidence.

The future model ledger keeps planned cells, actual provider attempts, visible answers, token usage, parsing errors, and resource stops. Probability-report failure does not erase a completed target action. Given k observed shortcuts, m missing outcomes, and n planned attempted episodes, the realized attempted-sample rate is bounded by [k/n,(k+m)/n] before any extra missingness assumption. Unstarted budget-blocked episodes are reported separately. Primary classification uses a fixed orientation, half credit at 0.5, paired label randomization, and correction for the planned model/family comparisons.

Reproduction commands appear in START_HERE.md. No hosted-model access is required for the CPU artifact. The network adapter has only been tested with mock completions here. Real runs require a fresh transport pilot, explicit authorization, exact model identifiers, current prices, and a frozen plan. Six hours is a workflow target, not a guarantee about an external provider's latency or quota.

## Appendix D. Limitations and Dual-Use Considerations

Local synthetic environments are not real deployments. Two mechanisms and a finite model set cannot support universal claims. Failure to find a distinguisher is not proof of indistinguishability. A hand-written witness establishes an available signal, not autonomous discovery. Reported probabilities may not be internal beliefs, and conditioning an action on evidence is not by itself evidence of malicious intent. A harmless shortcut task does not measure destructive behavior.

The model abstracts from social, legal, physical, and open-world processes. Unknown external actors, unmodeled timing, covert memory, inconsistent service state, and log truncation can break a claimed correspondence. Matching model-facing JSON fields does not prove that all infrastructure cues have been removed. Containment is a separate implementation claim; this small Python environment is not a hardened sandbox for adversarial code.

The artifact can help auditors avoid overclaiming, but examples might teach future agents or attackers how to recognize evaluation conditions. It contains no operational fingerprints, exploitation recipes, live credentials, or third-party targets. Potentially sensitive details from an authorized real audit require a separate disclosure review. All experiments must remain local, authorized, and non-destructive. Only explicitly authorized inference traffic may leave the experiment host; the evaluated agent receives no external network tool.

### LLM Usage Statement

This collaboration draft and implementation were developed with ChatGPT assistance for theory exploration, editing, code generation, and checking. The released CPU code and specified checkers were executed, and the document was rendered for inspection. No evaluated LLM experiment was run in this release. These programmatic checks are not an independent human theorem review. Human authors must verify the claims, sources, author details, and final writing before submission; the sprint materials require the team's own report. Codex is the proposed executor for the next bounded experiment, not an author whose unperformed work is being credited.

### Exactly four one-month extensions

**1. Scale to more models, seeds, environments, and longer horizons.** Test the prospective model study and broaden causal mechanisms while retaining complete failure accounting.

**2. Search or train adaptive probe policies and compare them with general-purpose agents.** Separate elicited exploitation from search success and avoid equating either with intent.

**3. Conduct an authorized leakage audit of an existing agent evaluation environment.** Validate the actual observation boundary and reset assumptions before making any deployment-relevant statement.

**4. Strengthen the formal analysis for partial observability, composition, and open-world external actors.** Prioritize justified deployment uncertainty and persistent memory without changing the specified behavioral target.
